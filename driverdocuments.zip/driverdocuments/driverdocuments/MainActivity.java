package pram.techvedika.com.driverdocuments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String[] listitems={"Driving License","Vehicle Insurance","Vehicle Registration","Social Security Number","Drug Test","Vehicle Inspected"};
    String[] uploadinfo={"Upload a photo of your driver's license","Upload a photo of your vehicle Insurance","Upload a photo of your vehicle Registration","Upload a photo of your SSN card","Upload a photo of your Drug test certificate","Upload a photo of your Vehicle Inspection Certificate "};
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View view=getLayoutInflater().inflate(R.layout.activity_main,null);
        ScrollView scrollView=new ScrollView(this);
        scrollView.addView(view);
        MyListAdapter myListAdapter=new MyListAdapter(this,listitems,uploadinfo);
        listView=(ListView)findViewById(R.id.mainList);
        listView.setAdapter(myListAdapter);
   }
}
