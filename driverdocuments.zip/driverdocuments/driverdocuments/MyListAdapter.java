package pram.techvedika.com.driverdocuments;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MyListAdapter extends BaseAdapter {
    Context context;
    String[] listitems;
    String[] uploadinfo;
    LayoutInflater layoutInflater;
    MyListAdapter(Context context,String[] listitems,String[] uploadinfo)
    {
        this.context=context;
        this.listitems=listitems;

        layoutInflater=LayoutInflater.from(context);
        this.uploadinfo=uploadinfo;
    }
    @Override
    public int getCount() {
        return listitems.length;
    }
    @Override
    public Object getItem(int position) {
        return null;
    }
    @Override
    public long getItemId(int position) {
        return 0;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view=layoutInflater.inflate(R.layout.expandable_parent_list,null);
        TextView textView=(TextView)view.findViewById(R.id.tv_document_options);
        textView.setText(listitems[position]);
        TextView tv_info=(TextView)view.findViewById(R.id.dri_lic_document_upload_text);
        tv_info.setText(uploadinfo[position]);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RelativeLayout relativeChild=(RelativeLayout)v.findViewById(R.id.relative_child);
                RelativeLayout relativeParent=(RelativeLayout)v.findViewById(R.id.relative_parent);
                ImageButton image_right=(ImageButton)v.findViewById(R.id.image_right_arrow);
                if(relativeChild.getVisibility()==View.GONE)
                {
                    relativeChild.setVisibility(View.VISIBLE);
                    relativeParent.setBackgroundColor(Color.parseColor("#EAEAEA"));
                    image_right.setImageResource(R.drawable.ic_keyboard_arrow_down);
                }
                else {
                    relativeChild.setVisibility(View.GONE);
                    relativeParent.setBackgroundColor(Color.TRANSPARENT);
                    image_right.setImageResource(R.drawable.ic_keyboard_arrow_right);
                }
            }
        });
        return view;
    }
}
